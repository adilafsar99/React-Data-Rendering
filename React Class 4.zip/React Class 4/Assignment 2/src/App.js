import FirstQ from "./components/FirstQ/FirstQ.js";
import SecondQ from "./components/SecondQ/SecondQ.js";
import ThirdQ from "./components/ThirdQ/ThirdQ.js";

function Questions() {
  return(
    <div>
      <FirstQ />
      <SecondQ />
      <ThirdQ />
    </div>
  )
}

export default Questions;