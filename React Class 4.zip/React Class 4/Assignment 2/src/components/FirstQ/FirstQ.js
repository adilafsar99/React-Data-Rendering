import './FirstQ.css';

function Name() {
  const name = "Hello World";
  return(
    <div className="name-div">
       <h2 className="name-heading">Variable</h2>
       <p className="name-p">{name}</p>
    </div>
    )
}

function Obj() {
  const obj = {name: "Hello World Object"};
  return(
    <div className="obj-div">
       <h2 className="obj-heading">Object</h2>
       <p className="obj-p">{obj.name}</p>
    </div>
    )
}

function Data() {
  const data = ["We", "are", "United"];
  return(
    <div className="arr-div">
       <h2 className="arr-heading">Array</h2>
       {data.map((v, i) => <p className="arr-p">{v}</p>)}
    </div>
    )
}


function List() {
  const list = [{name: "Hello World 1"}, {name: "Hello World 2"}, {name: "Hello World 3"}];
  return(
    <div className="arr-of-obj-div">
       <h2 className="arr-of-obj-heading">Array Of Objects</h2>
       {list.map((v, i) => <p className="arr-of-obj-p">{v.name}</p>)}
    </div>
    )
}

function Complex() {
  const complex = [{company: "XYZ", jobs: ["JavaScript", "React"]}, {company: "ABC", jobs: ["Angular JS", "Ionic"]}];
  return(
    <div className="arr-in-obj-div">
       <h2 className="arr-in-obj-heading">Array In Objects</h2>
       <table className="table">
         <tr className="row">
            <th className="table-heading">Company</th>
            <th className="table-heading">Jobs</th>
         </tr>
            {complex.map((v, i) => {
              return(
              <tr>
                 <td>{v.company}</td>
                 <td>{v.jobs.join(", ")}</td>
              </tr>
            )})}
       </table>
    </div>
    )
}

function FirstQ() {
  return(
    <div className="q-div">
       <h1>First Question</h1>
       <Name />
       <Obj />
       <Data />
       <List />
       <Complex />
    </div>
  )
}

export default FirstQ;