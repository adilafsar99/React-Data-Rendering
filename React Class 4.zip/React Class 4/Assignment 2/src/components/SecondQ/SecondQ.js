function ImportTypes() {
  return(
    <div className="import-types">
      <h2 className="import-types-heading">
        Single Vs Multi Import
      </h2>
      <p className="import-types-p">
        When a file exports a single function or component, it is imported by using a name and specifying the file path. The syntax:<br /><br />
        <b>import Name from "./FilePath"</b><br /><br />
        Here "Name" is just a container that is used to store the imported component/function. It does not have to match the name of the imported data.<br /><br />
        When importing multiple files, the name of functions/components  are enclosed in curly braces. The syntax:<br /><br />
        <b>import {`{Name1, Name2}`} from "./FilePath"</b><br /><br />
        Here, Name1 and Name2 have to be the same as the name of the imported functions/components or else the code won't work.
      </p>
    </div>
  )
}

function SecondQ() {
  return(
    <div className="q-div">
       <h1>Second Question</h1>
       <ImportTypes />
    </div>
  )
}

export default SecondQ;